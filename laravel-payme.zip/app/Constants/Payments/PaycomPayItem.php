<?php

namespace App\Constants\Payments;

class PaycomPayItem
{
    const EVENT = 'event';
    const LICENSE = 'license';
}
