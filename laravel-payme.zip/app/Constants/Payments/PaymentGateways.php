<?php

namespace App\Constants\Payments;

class PaymentGateways
{
   const OCTO_PAY = 'octo';
   const PAYCOM_PAY = 'paycom';
}
